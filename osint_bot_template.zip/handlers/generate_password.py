# Generate password handler
